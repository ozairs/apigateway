context.set('message.headers.x-selected-scope', 'weather california');
context.set('message.status.code', 200);