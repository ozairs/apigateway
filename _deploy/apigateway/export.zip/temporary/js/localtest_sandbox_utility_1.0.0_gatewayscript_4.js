context.message.body.write({"message":"hello world!"});
context.message.header.set('Content-Type', 'application/json');